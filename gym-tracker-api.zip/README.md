
# Backend PHP (puro) — Gym Tracker
Requisitos: PHP 8.1+, MySQL, Composer.
Rode `composer install` nesta pasta para instalar o PhpSpreadsheet.
Ajuste credenciais/CORS em `api/config.php`.
